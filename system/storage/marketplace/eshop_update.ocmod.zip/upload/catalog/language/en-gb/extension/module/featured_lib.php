<?php
// Heading
$_['heading_title'] = 'Picked For You';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_shop']      = 'Shop Now';
$_['text_topselling']      = 'Top Selling';