<?php
// Heading
$_['heading_title'] = 'Deals Of The Day';

// Text
$_['text_tax']      = 'Ex Tax:';