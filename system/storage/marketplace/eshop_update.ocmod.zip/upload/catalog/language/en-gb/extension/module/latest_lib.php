<?php
// Heading
$_['heading_title'] = 'Latest Products';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_topselling']      = 'Top Selling';